const Dashboard = () => {
  return (
    <div>
      <h1>Welcome to my movie Dashboard</h1>
    </div>
  );
};

export default Dashboard;
